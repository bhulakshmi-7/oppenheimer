package util;

import java.util.Properties;

public class PropUtils {
    /**
     * Description : This class is used to get the properties from config.properties file.
     */
    public String getValue(String property) {
        ConfigReader configReader =new ConfigReader();
        Properties configProp = configReader.init_prop();
        String value = configProp.getProperty(property);
        if(value  != null) return value ;
        else throw new RuntimeException("Selected Value not specified in the config.properties file.");
    }

}
