package util;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import java.util.Map;
import java.util.TreeMap;

public class ExcelHandler {
    /**
     * Description : This class is used to get the Excel Test Data from the WorkSheet.This class is used
     * to get the Excel Test Data from the WorkSheet using Fillo Excel API.
     */

    PropUtils propUtils=new PropUtils();
    public Map<String, String> ReadExcelDataBasedOnNatID(String sheetname, String natid) throws Exception {
        Map<String,String> TestDataInMap=new TreeMap<String,String>();
        Fillo fillo = new Fillo();
        Connection conn = fillo.getConnection(propUtils.getValue("excel_filepath"));
        Recordset recordset = null;
        String query = null;
        query = "SELECT * FROM " + sheetname + " WHERE natid=" + "'" + natid + "'";
        try {
            recordset = conn.executeQuery(query);
            while (recordset.next()) {
                for (String field : recordset.getFieldNames()) {
                    TestDataInMap.put(field, recordset.getField(field));
                }
            }

            recordset.close();
        } catch (FilloException e) {
            e.printStackTrace();
            throw new Exception("Test data cannot find . . .");
        }
        conn.close();
        return TestDataInMap;
    }
    public Map<String, String> ReadExcelData(String sheetname) throws Exception {
        Map<String,String> testData=new TreeMap<String,String>();
        Fillo fillo = new Fillo();
        Connection conn = fillo.getConnection(propUtils.getValue("excel_filepath"));
        Recordset recordset = null;
        String query = null;
        query = "SELECT * FROM " + sheetname ;
        try {
            recordset = conn.executeQuery(query);
            while (recordset.next()) {
                String natid = recordset.getField("natid");
                String relief = recordset.getField("relief");
                testData.put(natid,relief);
            }

            recordset.close();
        } catch (FilloException e) {
            e.printStackTrace();
            throw new Exception("Test data cannot find . . .");
        }
        conn.close();
        return testData;
    }
}
