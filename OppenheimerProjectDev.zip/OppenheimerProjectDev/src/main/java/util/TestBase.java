package util;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import qa.factory.DriverFactory;
import util.ConfigReader;

import java.io.File;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class TestBase {
    protected String screenshotFileName = null;

    protected WebDriver driver;// an API to send commands directly to the browser
    protected WebDriverWait webdriverwait;
    Properties prop;
    @BeforeSuite()
    public Properties getProperty(){
        ConfigReader configReader=new ConfigReader();
        prop = configReader.init_prop();
        return prop;
    }
   @BeforeClass()
    public void setupWebDriver() {
        String browserName=prop.getProperty("browser");
        DriverFactory driverFactory = new DriverFactory();
        driver=driverFactory.init_driver(browserName);
        driver.get(prop.getProperty("URL"));
    }

    @AfterClass
    public void cleanup() {
        driver.quit();
    }

    @AfterMethod
    public void saveScreenshot() throws IOException {
        if (screenshotFileName != null) {
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot, new File(screenshotFileName));
        }
    }
}
