package testCases;

import io.restassured.RestAssured;
import io.restassured.common.mapper.TypeRef;
import io.restassured.response.Response;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.SourceType;
import org.testng.Assert;
import org.testng.annotations.Test;
import util.ExcelHandler;
import util.MaskString;
import util.PropUtils;
import util.TestBase;

import java.io.File;
import java.util.*;


import static io.restassured.RestAssured.given;

public class TC_OppenheimerProjectDev extends TestBase{
    public PropUtils propUtils=new PropUtils();
    ExcelHandler excelHandler =new ExcelHandler();
    MaskString maskString=new MaskString();
    /*(1) Insert a single record of working class hero into database via an API*/
    @Test(priority = 1)
    public void test_insertSingle_classHero() throws Exception {
        Map<String,String> TestDataInMap= excelHandler.ReadExcelDataBasedOnNatID("WorkingClassHero","1008008");
        String birthday_value=TestDataInMap.get("birthday");
        String gender_value=TestDataInMap.get("gender");
        String name_value=TestDataInMap.get("name");
        String natid_value=TestDataInMap.get("natid");
        String salary_value=TestDataInMap.get("salary");
        String tax_value=TestDataInMap.get("tax");
        Map<String,String> data = new HashMap<String,String>();
        data.put("birthday", birthday_value);
        data.put("gender", gender_value);
        data.put("name", name_value);
        data.put("natid", natid_value);
        data.put("salary", salary_value);
        data.put("tax", tax_value);
        Response res =
                given()
                        .contentType("application/json")
                        .body(data)
                        .when()
                        .post("http://localhost:8080/calculator/insert")

                        .then()
                        .statusCode(202)
                        .log().body()
                        .extract().response();

        String jsonString = res.asString();
        Assert.assertEquals(jsonString.contains("Alright"), true);
    }
    /*(2) Insert more than one working class hero into database via an API*/
    @Test(priority = 2)
    public void test_insertMultiple_classHero() throws Exception {
        //First working class hero
        Map<String,String> TestDataInMap_Person1= excelHandler.ReadExcelDataBasedOnNatID("WorkingClassHero","1009009");
        String birthday_value1=TestDataInMap_Person1.get("birthday");
        String gender_value1=TestDataInMap_Person1.get("gender");
        String name_value1=TestDataInMap_Person1.get("name");
        String natid_value1=TestDataInMap_Person1.get("natid");
        String salary_value1=TestDataInMap_Person1.get("salary");
        String tax_value1=TestDataInMap_Person1.get("tax");

        Map<String,String> data1 = new HashMap<String,String>();
        data1.put("birthday", birthday_value1);
        data1.put("gender", gender_value1);
        data1.put("name", name_value1);
        data1.put("natid", natid_value1);
        data1.put("salary", salary_value1);
        data1.put("tax", tax_value1);
        //Second working class hero
        Map<String,String> TestDataInMap_Person2= excelHandler.ReadExcelDataBasedOnNatID("WorkingClassHero","1010010");
        String birthday_value2=TestDataInMap_Person2.get("birthday");
        String gender_value2=TestDataInMap_Person2.get("gender");
        String name_value2=TestDataInMap_Person2.get("name");
        String natid_value2=TestDataInMap_Person2.get("natid");
        String salary_value2=TestDataInMap_Person2.get("salary");
        String tax_value2=TestDataInMap_Person2.get("tax");

        Map<String,String> data2 = new HashMap<String,String>();
        data2.put("birthday", birthday_value2);
        data2.put("gender", gender_value2);
        data2.put("name", name_value2);
        data2.put("natid", natid_value2);
        data2.put("salary", salary_value2);
        data2.put("tax", tax_value2);
        List<Map<String,String>> jsonArrayPayload = new ArrayList<>();
        jsonArrayPayload.add(data1);
        jsonArrayPayload.add(data2);

        Response res1 =
                given()
                        .contentType("application/json")
                        .body(jsonArrayPayload)
                        .when()
                        .post("http://localhost:8080/calculator/insertMultiple")
                        .then()
                        .statusCode(202)
                        .log().body()
                        .extract().response();
        String jsonString = res1.asString();
        Assert.assertEquals(jsonString.contains("Alright"), true);
    }
 /*(3) Upload a csv file to a portal*/
    @Test(priority = 3)
    public void test_uploadLargeFileUsingApi() {
        String excelFilepath=propUtils.getValue("upload_file");
        String response =
                RestAssured.given()
                        .multiPart("file", new File(excelFilepath)).
                        when().post("http://localhost:8080/calculator/uploadLargeFileForInsertionToDatabase").then().statusCode(200).
                        extract().asString();
        Assert.assertEquals(response.contains("Successfully uploaded"), true);
    }
    @Test(priority = 4)
    public void test_uploadLargeFileUsingPortal() {
        WebElement uploadElement = driver.findElement(By.xpath("//input[@class='custom-file-input']"));
        uploadElement.sendKeys("C:\\Users\\P0104547\\IdeaProjects\\OppenheimerProjectDev\\test.csv");
        WebElement refreshTaxReliefTable=driver.findElement(By.xpath("//button[contains(@class,'btn btn-primary')]"));
        refreshTaxReliefTable.click();
    }
  /*(4) AC1: a GET endpoint which returns a list consist of natid, tax relief
 amount and name
AC2: natid field must be masked from the 5th character onwards with
 dollar sign ‘$’ */
    @Test(priority = 5)
    public void test_getNatid() {
        List<Map<String,Object>> response = null;
        response  = given()

                .when()
                .get("http://localhost:8080/calculator/taxRelief")

                .then()
                .statusCode(200)
                .extract().body()
                // Extract response as List<Map<String,Object>>
                // Since the response in a List of Map format.
                .as(new TypeRef<List<Map<String,Object>>>() {});
        for(Map<String,Object> map : response)
        {
            String natidApi = (String) map.get("natid");
            Assert.assertEquals(natidApi.substring(4),"$$$","5th character onwards with" +
                    "dollar sign");
        }

    }
    /* AC3,AC4,AC5,AC6: Verify Tax Relief*/
    @Test(priority = 6)
    public void test_getTaxRelief() throws Exception {
        Map<String,String> excelMap= excelHandler.ReadExcelData("WorkingClassHero");
        String returned_value = (String)excelMap.remove("");
        List<Map<String,Object>> responseBody = null;
        responseBody =
                RestAssured
                        .given()
                        .baseUri("http://localhost:8080/calculator/taxRelief")
                        .when()
                        .get()
                        .then()
                        .statusCode(200)
                        .extract()
                        .body()
                        // Extract response as List<Map<String,Object>>
                        // Since the response in a List of Map format.
                        .as(new TypeRef<List<Map<String,Object>>>() {});

        Map<String,String> swagger=new HashMap<String,String>();
        for(Map<String,Object> map : responseBody)
        {
            String natidApi = (String) map.get("natid");
            String reliefApi= (String) map.get("relief");
            swagger.put(natidApi,reliefApi);
        }
        Iterator<String> it=excelMap.keySet().iterator();
        while(it.hasNext()){
            String key=it.next();
            String excelKey=MaskString.maskString(key, 4, 7, '$');
            if(swagger.get(excelKey)!=null && swagger.get(excelKey).equals(excelMap.get(key))){
                System.out.println("Excel Relief "+excelMap.get(key) + "=> Swagger Relief " +swagger.get(excelKey) +" values are matched");
            }else{
                System.out.println("Excel Relief "+excelMap.get(key) + "=> Swagger Relief " +swagger.get(excelKey) +" values are un matched");
            }
        }
    }
//
    /*(5) As the Governor, I should be able to see a button on the screen so
    that I can dispense tax relief for my working class heroes*/
    /* AC1: The button on the screen must be red-colored*/
    @Test(priority = 7)
    public void verifyDispenseButtonColor() {
        WebElement dispenseNowBtn = driver.findElement(By.xpath("//a[contains(.,'Dispense Now')]"));
        TC_OppenheimerProjectDev.scrollIntoView(dispenseNowBtn,driver);
        String color = dispenseNowBtn.getCssValue("background-color");
        String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");
        int hexValue1=Integer.parseInt(hexValue[0]);
        hexValue[1] = hexValue[1].trim();
        int hexValue2=Integer.parseInt(hexValue[1]);
        hexValue[2] = hexValue[2].trim();
        int hexValue3=Integer.parseInt(hexValue[2]);
        String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);
        Assert.assertEquals("#dc3545", actualColor);
    }
    /* AC2: The text on the button must be exactly “Dispense Now” */
    @Test(priority = 8)
    public void verifyDispenseNowButton() {
        WebElement dispenseNowText = driver.findElement(By.linkText("Dispense Now"));
        TC_OppenheimerProjectDev.scrollIntoView(dispenseNowText,driver);
        Assert.assertEquals("Dispense Now", dispenseNowText.getText());
    }
    /*AC3: After clicking on the button, it should direct me to a page with a
  text that says “Cash dispensed” */
    @Test(priority = 9)
    public void userClickOnDispenseNow(){
        WebElement dispenseNowClick = driver.findElement(By.linkText("Dispense Now"));
        TC_OppenheimerProjectDev.scrollIntoView(dispenseNowClick,driver);
        dispenseNowClick.click();
        WebElement cashDispensed=driver.findElement(By.xpath("//div[contains(text(),'Cash dispensed')]"));
        Assert.assertEquals("Cash dispensed", cashDispensed.getText());

    }
    public static void scrollIntoView(WebElement element, WebDriver driver){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);",element);
    }
}

